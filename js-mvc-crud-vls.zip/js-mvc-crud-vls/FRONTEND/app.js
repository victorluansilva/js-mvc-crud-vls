import { controller } from "./src/controller.js";

controller.run();