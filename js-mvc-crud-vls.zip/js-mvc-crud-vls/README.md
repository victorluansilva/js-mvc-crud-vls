## Welcome to my pratical MVC CRUD project in JS

Here I'm exploring more about MVC design pattern and CRUD in JavaScript.

- BACKEND was built in node.js enviroment;
- FRONTEND totally built in vanilla JavaScript

---

### Give it a go?

1. Download it
    > Be sure you already have node.js onto your system

2. Then run bellow code to install needed dependencies

    ~~~
    npm install
    ~~~

3. Now you're ready to go, just run:

    ~~~
    npm start
    ~~~